eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(6($){$.1K.d=6(x){3 1g=$.1a({y:4,I:1O,1u:r,1q:1P,1b:f,1d:r,1E:f,q:f,1e:{1M:{v:1L,y:1},1N:{v:1Y,y:2},1W:{v:1S,y:14}}},x);3 5=$(M);3 8=$.1a(1g,x);3 9;3 h=f;3 p=8.y;3 Z=5.t().1G;3 w=[];3 e={1h:6(){N M.1U(6(){e.1A();e.1l();e.1f()})},1f:6(){3 j=5.s();3 X=j.D();3 c=5.t();e.1x(8.1e);3 l=j.m();9=(l)/p;c.m(9);7(8.q){c.F().S(c.K());c.F().S(c.K());5.o({\'k\':-9})}5.1V();$(1k).1Q("1j")},1A:6(){5.1J("g-d-21");5.1Z("<n u=\'g-d-1R\'><n u=\'g-d-20\'></n><n u=\'1X\'></n></n>");5.Q("1T").1J("g-d-B");3 C=5.s();7(8.1d){3 1c=$(".g-d-B L").m();3 1s=$(".g-d-B L").D();$(".g-d-B L").o("1i-m",1c);$(".g-d-B L").o("1i-D",1s)}$("<n u=\'g-d-J-k\'><i u=\'O O-1D-k\'></i></n><n u=\'g-d-J-U\'><i u=\'O O-1D-U\'></i></n>").1I(C);7(8.q){3 1m=5.t().q();5.27(1m)}},1l:6(){3 j=5.s();3 C=j.s();3 c=5.t();3 A=C.Q(".g-d-J-k");3 E=C.Q(".g-d-J-U");$(1k).G("1j",6(R){e.1v();3 l=$(j).m();3 X=$(j).D();9=(l)/p;c.m(9);7(8.q){5.o({\'k\':-9})}z{5.o({\'k\':0})}7(!8.q&&Z<=p){A.1n(E).o(\'1o\',\'2n\')}z{A.1n(E).o(\'1o\',\'2m\');3 1p=(A.D())/2;3 Y=(X/2)-1p;A.o("1t",Y+"19");E.o("1t",Y+"19")}});$(A).G("18",6(R){e.1B()});$(E).G("18",6(R){e.V()});7(8.1b==f){$(".g-d-B").G({2l:6(){h=r},2j:6(){h=f}})}7(8.1u==f){2k(6(){7(h==f)e.V()},8.1q)}},1v:6(){3 W=$(\'2o\').m();7(8.1E){3 1H=w[w.1G-1].v;1w(3 i 15 w){7(W>=1H){p=8.y;1F}z{7(W<w[i].v){p=w[i].y;1F}z 22}}}},1x:6(T){3 H=[];1w(3 i 15 T){H.2q(T[i])}H.2r(6(a,b){N a.v-b.v});w=H},1B:6(){7(5.1y().k<0){7(h==f){h=r;3 j=5.s();3 l=j.m();9=(l)/p;3 c=5.t();5.11({\'k\':"+="+9},{13:r,12:8.I,10:"16",17:6(){7(8.q){c.F().S(c.K())}e.P();h=f}})}}},V:6(){3 j=5.s();3 l=j.m();9=(l)/p;3 1C=(9-l);3 1z=(5.1y().k+((Z-p)*9)-l);7((1C<=2h.2i(1z))&&(!8.q)){7(h==f){h=r;5.11({\'k\':"-="+9},{13:r,12:8.I,10:"16",17:6(){e.P();h=f}})}}z 7(8.q){7(h==f){h=r;3 c=5.t();5.11({\'k\':"-="+9},{13:r,12:8.I,10:"16",17:6(){c.K().1I(c.F());e.P();h=f}})}}},P:6(){3 j=5.s();3 c=5.t();3 l=j.m();9=(l)/p;c.m(9);7(8.q){5.o({\'k\':-9})}}};7(e[x]){N e[x].1r(M,28.26.25.23(24,1))}z 7(29 x===\'5\'||!x){N e.1h.1r(M)}z{$.2a(\'2f "\'+2g+\'" 2e 2d 2b 15 d 2c!\')}}})(2p);',62,152,'|||var||object|function|if|settings|itemsWidth|||childSet|flexisel|methods|true|nbs|canNavigate||listParent|left|innerWidth|width|div|css|itemsVisible|clone|false|parent|children|class|changePoint|responsivePoints|options|visibleItems|else|leftArrow|item|flexiselInner|height|rightArrow|last|on|responsiveObjects|animationSpeed|nav|first|img|this|return|fa|adjustScroll|find|event|insertBefore|obj|right|scrollRight|contentWidth|innerHeight|arrowMargin|totalItems|easing|animate|duration|queue||in|linear|complete|click|px|extend|pauseOnHover|baseWidth|setMaxWidthAndHeight|responsiveBreakpoints|initializeItems|defaults|init|max|resize|window|setEventHandlers|cloneContent|add|visibility|halfArrowHeight|autoPlaySpeed|apply|baseHeight|top|autoPlay|setResponsiveEvents|for|sortResponsiveObject|position|objPosition|appendHTML|scrollLeft|difObject|angle|enableResponsiveBreakpoints|break|length|largestCustom|insertAfter|addClass|fn|480|portrait|landscape|200|3000|trigger|container|768|li|each|fadeIn|tablet|clear|640|wrap|inner|ul|continue|call|arguments|slice|prototype|append|Array|typeof|error|exist|plugin|not|does|Method|method|Math|ceil|mouseleave|setInterval|mouseenter|visible|hidden|html|jQuery|push|sort'.split('|'),0,{}))

$(document).ready(function(){
	$("#flexisel").flexisel({
		visibleItems: 5,
		animationSpeed: 1000,
		autoPlay: true,
		autoPlaySpeed: 5000,
		pauseOnHover: true,
		enableResponsiveBreakpoints: true,
		responsiveBreakpoints: {
			portrait: { 
				changePoint:480,
				visibleItems: 2
			},
			landscape: {
				changePoint:640,
				visibleItems: 3
			},
			tablet: {
				changePoint:768,
				visibleItems: 3
			}
		}
	});
});