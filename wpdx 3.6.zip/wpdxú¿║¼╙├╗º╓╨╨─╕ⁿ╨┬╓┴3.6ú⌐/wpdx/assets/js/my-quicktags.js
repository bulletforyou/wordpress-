quicktags({
	id: "comment",
	buttons: "strong,em,link,code,link,img"
});
QTags.addButton('quote','quote','<blockquote>','</blockquote>','quote','引用',22);