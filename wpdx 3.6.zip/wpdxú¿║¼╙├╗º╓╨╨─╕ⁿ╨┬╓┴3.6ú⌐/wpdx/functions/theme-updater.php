<?php
define("THEME_DOC", "#");
define("THEME_URI", "#");
define("THEME_UPDATE_FAQ", "#");
add_filter("http_request_args", "cmp_disable_wporg_request", 5, 2);
if (!class_exists("cmpUserFrontendPost")) {
	include_once TEMPLATEPATH . "/cmpuser/includes/cmpuser-frontend-post.php";
	$cmpuser_frontend_post = new cmpUserFrontendPost();
}
if (!function_exists("show_cmpuser_login_form")) {
	include_once TEMPLATEPATH . "/cmpuser/cmpuser.php";
	add_shortcode("cmpuser-login", "show_cmpuser_login_form");
	add_shortcode("cmpuser-register", "show_cmpuser_register_form");
	add_shortcode("cmpuser-reset-password", "show_cmpuser_reset_password_form");
}
$domain = $_SERVER["SERVER_NAME"];
$product = "7";
$licenseServer = "";
$postvalue = "domain=" . $domain . "&product=" . urlencode($product);
$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, $licenseServer);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postvalue);
$result = json_decode(curl_exec($ch), true);
curl_close($ch);
function cmp_disable_wporg_request($_var_18, $_var_19)
{
	if (0 !== strpos($_var_19, "https://api.wordpress.org/themes/update-check/1.1/")) {
		return $_var_18;
	}
	$_var_20 = json_decode($_var_18["body"]["themes"]);
	$_var_21 = get_option("template");
	$_var_22 = get_option("stylesheet");
	unset($_var_20->themes->{$_var_21});
	unset($_var_20->themes->{$_var_22});
	$_var_18["body"]["themes"] = json_encode($_var_20);
	return $_var_18;
}
function do_output_buffer()
{
	ob_start();
}