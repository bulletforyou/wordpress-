<!DOCTYPE html>
<html <?php language_attributes(); if( cmp_get_option('show_weibo')) echo ' xmlns:wb="http://open.weibo.com/wb"';?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-transform" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit">
    <meta name="applicable-device" content="pc,mobile">
    <?php wp_head(); ?>
</head>
  <style type="text/css" media="screen">.bc-icon {
    position: absolute;
    width: 215px;
    height: 162px;
    right: 0px;
    position: absolute;
    z-index: 1;
    background: url(http://cdn.weknow.cn/images/mei.png) no-repeat 0 0;
}
.fox-youhui {
    position: fixed;
    right: 3.3%;
    bottom: 305px;
    width: 120px;
    height: 270px;
    background: #fff;
    z-index: 99;
    box-shadow: 0 0 50px #e5a42a;
    border-radius: 4px;
}

.fox-youhui img {
    width: 120px;
    height: 270px;
    display: block;
    vertical-align: top
}
.fox-1111 {
    position: fixed;
    bottom: 98px;
    width: 180px;
}
.fox-1111 img {
    width: 180px;
    display: block;
    vertical-align: top;
}</style>
<body id="top" <?php body_class(); ?>>
<div class="body-wrap">
    <div id="top-part">
        <?php get_template_part( "includes/top-bar" ) ?>
        <header id="header" role="banner">
            <nav id="main-nav"<?php if( cmp_get_option('theme_layout') =='vertical' && cmp_get_option('nav_fixed')) echo ' class="nav-fixed"'; ?> role="navigation">
            <div id="menu-button"><i class="fa fa-bars fa-fw"></i><?php _e('Navigation menu','wpdx');?></div>
                <ul>
                    <?php if(function_exists('wp_nav_menu')) wp_nav_menu(array('container' => false, 'items_wrap' => '%3$s','theme_location' => 'main-menu', 'fallback_cb' => 'cmp_nav_fallback','walker' => new wp_bootstrap_navwalker() )) ; ?>
                </ul><div class="clear"></div>
            </nav>
        </header>
    </div>
    <div id="main-content">