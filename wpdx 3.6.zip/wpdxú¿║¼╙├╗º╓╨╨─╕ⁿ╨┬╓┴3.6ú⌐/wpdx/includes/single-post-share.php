<div class="social-share" data-mobile-sites="weibo,wechat,qq,qzone,tencent,douban" data-image="<?php echo cmp_get_first_image(); ?>"></div>
